# Trendy Zone Android Starter (বাংলা নির্দেশিকা)

এই প্রজেক্টটি `https://trendyzone5.blogspot.com` সাইটের জন্য একটি **প্রাথমিক Android Studio WebView starter**। এটি চূড়ান্ত Play Store রিলিজ নয় এবং নিজে থেকে `.aab` তৈরি করে দেয় না।

## এতে যা আছে
- Trendy Zone Blogger সাইট WebView-তে খোলে
- JavaScript ও DOM storage চালু (Blogger থিম/কার্টের জন্য)
- লোডিং প্রগ্রেস
- নেটওয়ার্ক ব্যর্থ হলে পুনরায় চেষ্টা
- Back button ও exit confirmation
- ফোন/ইমেইল/বাহ্যিক লিংক হ্যান্ডলিং
- `targetSdk 36` ও `compileSdk 36`
- Package name: `com.trendyzone.shop`

## Android Studio-তে খোলার নিয়ম
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP ফাইল Extract করুন।
3. Android Studio > Open নির্বাচন করে `TrendyZoneAndroidStarter` ফোল্ডার খুলুন।
4. Gradle sync সম্পন্ন হতে দিন। JDK 17 এবং Android SDK Platform 36 ইনস্টল থাকতে হবে।
5. একটি Android ফোনে Developer options ও USB debugging চালু করে USB দিয়ে যুক্ত করুন, অথবা Emulator চালান।
6. Run ▶ চাপুন এবং পরীক্ষা করুন:
   - হোমপেজ ও পণ্য
   - কার্ট/Checkout
   - অর্ডার সাবমিট
   - Google Sheet-এ অর্ডার
   - ইমেইল নোটিফিকেশন
   - Back button, বাহ্যিক লিংক ও দুর্বল ইন্টারনেট

## ওয়েবসাইটের ঠিকানা ভবিষ্যতে বদলাতে
`app/src/main/java/com/trendyzone/shop/MainActivity.java` ফাইলে `STORE_URL` পরিবর্তন করুন। ভবিষ্যতে নিজস্ব ডোমেইন যুক্ত করলে `handleUrl()`-এ অনুমোদিত হোস্টও আপডেট করতে হবে। TWA ব্যবহার করতে চাইলে `assetlinks.json`-সহ আলাদা যাচাইকরণ প্রয়োজন; এই WebView starter সেটি নয়।

## Push notification — এখনও কনফিগার করা হয়নি
এই starter-এ OneSignal SDK বা Firebase credentials যুক্ত নেই। এগুলো আপনার নিজস্ব OneSignal App ID ও Firebase/FCM সেটিংস অনুযায়ী যোগ করতে হবে। কোনো App ID বা secret এখানে বানিয়ে দেওয়া হয়নি।

প্রয়োজনীয় কাজ:
1. OneSignal-এ Android প্ল্যাটফর্ম যোগ করুন।
2. Firebase Console-এ Android app তৈরি করুন এবং `com.trendyzone.shop` package name ব্যবহার করুন।
3. Firebase থেকে `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
4. OneSignal-এর বর্তমান অফিসিয়াল Android SDK নির্দেশিকা অনুসারে SDK dependency ও initialization যোগ করুন: https://documentation.onesignal.com/docs/android-sdk-setup
5. Android 13+ এ নোটিফিকেশন অনুমতি চাওয়া, সম্মতি নেওয়া এবং পরীক্ষামূলক push পাঠানো যাচাই করুন।
6. Blogger-এ নতুন পোস্ট হলেই নোটিফিকেশন পাঠানোর automation আলাদাভাবে সেটআপ করতে হবে; SDK একাই নতুন পোস্ট শনাক্ত করে না।

## Play Store প্রকাশের আগে বাধ্যতামূলক যাচাই
- শুধু WebView দেখানো অ্যাপ Google Play-এ সীমিত কার্যকারিতার কারণে প্রত্যাখ্যাত হতে পারে। ব্যবহারকারীর জন্য প্রকৃত উপযোগী, স্থিতিশীল অ্যাপ-ফিচার যোগ ও পরীক্ষা করুন।
- Privacy Policy, Data safety, Content rating, store listing, app icon ও screenshots প্রস্তুত করুন।
- Play Console-এর বর্তমান target API ও testing requirements যাচাই করুন।
- Release signing key নিরাপদে রাখুন; কাউকে শেয়ার করবেন না।
- Checkout/পেমেন্ট, ব্যক্তিগত তথ্য, নোটিফিকেশন সম্মতি এবং external links পরীক্ষা করুন।
- এই starter কোনো Play Store approval-এর নিশ্চয়তা দেয় না।

## গুরুত্বপূর্ণ
- Package name প্রকাশের আগে চূড়ান্ত করুন; Play Store-এ প্রকাশের পর এটি বদলানো যায় না।
- অ্যাপটি আগে পরীক্ষামূলকভাবে চালান। বর্তমান অর্ডার ব্যবস্থা কাজ করলেও অ্যাপের মধ্যে আবার পরীক্ষা করতে হবে।
